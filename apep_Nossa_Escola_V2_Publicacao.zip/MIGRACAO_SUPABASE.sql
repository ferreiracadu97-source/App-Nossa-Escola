-- MIGRACAO_SUPABASE.sql — App Nossa Escola v2
-- Faça backup antes de executar. Revise políticas se já existirem dados reais.
-- Não apaga tabelas nem registros existentes.
create extension if not exists pgcrypto;

create table if not exists public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text, email text,
 role text not null default 'guardian',
 created_at timestamptz not null default now()
);
alter table public.profiles add column if not exists full_name text;
alter table public.profiles add column if not exists email text;
alter table public.profiles add column if not exists role text default 'guardian';
alter table public.profiles add column if not exists created_at timestamptz default now();

-- Normalize common Portuguese role values so teacher/director accounts are not treated as students.
update public.profiles set role = case
 when lower(trim(role)) in ('professor','professora','docente','teacher') then 'teacher'
 when lower(trim(role)) in ('diretor','diretora','direção','direcao','director') then 'director'
 when lower(trim(role)) in ('administrador','administradora','admin') then 'admin'
 when lower(trim(role)) in ('responsável','responsavel','pai','mãe','mae','guardian','parent') then 'guardian'
 when lower(trim(role)) in ('aluno','aluna','estudante','student') then 'student'
 else coalesce(nullif(trim(role),''),'guardian') end;

create table if not exists public.notices(id uuid primary key default gen_random_uuid(),title text not null,content text not null,author_id uuid references auth.users(id),author_name text,created_at timestamptz not null default now());
create table if not exists public.school_events(id uuid primary key default gen_random_uuid(),title text not null,description text,event_date timestamptz not null,author_id uuid references auth.users(id),created_at timestamptz not null default now());
create table if not exists public.messages(id uuid primary key default gen_random_uuid(),content text not null,sender_id uuid references auth.users(id),sender_name text,created_at timestamptz not null default now());
create table if not exists public.school_files(id uuid primary key default gen_random_uuid(),title text not null,file_url text not null,description text,author_id uuid references auth.users(id),created_at timestamptz not null default now());
create table if not exists public.attendance(id uuid primary key default gen_random_uuid(),student_name text not null,attendance_date date not null,status text not null,notes text,author_id uuid references auth.users(id),created_at timestamptz not null default now());
create table if not exists public.grades(id uuid primary key default gen_random_uuid(),student_name text not null,subject text not null,grade numeric(5,2) not null,term text not null,author_id uuid references auth.users(id),created_at timestamptz not null default now());
create table if not exists public.tasks(id uuid primary key default gen_random_uuid(),title text not null,description text,due_date date,author_id uuid references auth.users(id),created_at timestamptz not null default now());

create or replace function public.is_school_staff() returns boolean
language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles p where p.id=auth.uid() and lower(p.role) in ('teacher','director','admin','professor','professora','diretor','diretora','direção','direcao'));
$$;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,full_name,email,role)
 values(new.id,coalesce(new.raw_user_meta_data->>'full_name',split_part(new.email,'@',1)),new.email,'guardian')
 on conflict(id) do update set email=excluded.email, full_name=coalesce(public.profiles.full_name,excluded.full_name);
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.notices enable row level security;
alter table public.school_events enable row level security;
alter table public.messages enable row level security;
alter table public.school_files enable row level security;
alter table public.attendance enable row level security;
alter table public.grades enable row level security;
alter table public.tasks enable row level security;

-- Drop/recreate app policy names to make this script repeatable.
drop policy if exists "profiles read own or staff" on public.profiles;
create policy "profiles read own or staff" on public.profiles for select to authenticated using(id=auth.uid() or public.is_school_staff());
drop policy if exists "profiles update own name" on public.profiles;
create policy "profiles update own name" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
-- IMPORTANT: role changes should be made by trusted project owner via dashboard, not by the app.
-- Staff permissions for notices and calendar.
drop policy if exists "authenticated read notices" on public.notices;
create policy "authenticated read notices" on public.notices for select to authenticated using(true);
drop policy if exists "staff insert notices" on public.notices;
create policy "staff insert notices" on public.notices for insert to authenticated with check(public.is_school_staff() and author_id=auth.uid());
drop policy if exists "staff update notices" on public.notices;
create policy "staff update notices" on public.notices for update to authenticated using(public.is_school_staff()) with check(public.is_school_staff());
drop policy if exists "staff delete notices" on public.notices;
create policy "staff delete notices" on public.notices for delete to authenticated using(public.is_school_staff());
drop policy if exists "authenticated read events" on public.school_events;
create policy "authenticated read events" on public.school_events for select to authenticated using(true);
drop policy if exists "staff insert events" on public.school_events;
create policy "staff insert events" on public.school_events for insert to authenticated with check(public.is_school_staff() and author_id=auth.uid());
drop policy if exists "staff update events" on public.school_events;
create policy "staff update events" on public.school_events for update to authenticated using(public.is_school_staff()) with check(public.is_school_staff());
drop policy if exists "staff delete events" on public.school_events;
create policy "staff delete events" on public.school_events for delete to authenticated using(public.is_school_staff());
drop policy if exists "authenticated read messages" on public.messages;
create policy "authenticated read messages" on public.messages for select to authenticated using(true);
drop policy if exists "authenticated send messages" on public.messages;
create policy "authenticated send messages" on public.messages for insert to authenticated with check(sender_id=auth.uid());
drop policy if exists "authenticated read files" on public.school_files;
create policy "authenticated read files" on public.school_files for select to authenticated using(true);
drop policy if exists "staff insert files" on public.school_files;
create policy "staff insert files" on public.school_files for insert to authenticated with check(public.is_school_staff() and author_id=auth.uid());
-- Sensitive tables: staff-only. Configure student/guardian relationships before real use.
drop policy if exists "staff manage attendance" on public.attendance;
create policy "staff manage attendance" on public.attendance for all to authenticated using(public.is_school_staff()) with check(public.is_school_staff() and author_id=auth.uid());
drop policy if exists "staff manage grades" on public.grades;
create policy "staff manage grades" on public.grades for all to authenticated using(public.is_school_staff()) with check(public.is_school_staff() and author_id=auth.uid());
drop policy if exists "authenticated read tasks" on public.tasks;
create policy "authenticated read tasks" on public.tasks for select to authenticated using(true);
drop policy if exists "staff insert tasks" on public.tasks;
create policy "staff insert tasks" on public.tasks for insert to authenticated with check(public.is_school_staff() and author_id=auth.uid());

grant usage on schema public to authenticated;
grant select,insert,update,delete on public.profiles,public.notices,public.school_events,public.messages,public.school_files,public.attendance,public.grades,public.tasks to authenticated;
