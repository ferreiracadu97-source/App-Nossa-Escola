// Renomeie este arquivo para config.js e preencha os dois valores.
// Use apenas Project URL e a chave anon/public. NUNCA use service_role/secret no navegador.
window.APP_CONFIG = {
  SUPABASE_URL: "https://SEU-PROJETO.supabase.co",
  SUPABASE_ANON_KEY: "COLE_AQUI_SUA_CHAVE_ANON_PUBLIC"
};